"""
Utility functions for plotting: regression stats, axis helpers, grid layouts.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from math import ceil


def deming_lambda(sigma_x, sigma_y):
    """Error-variance ratio lambda = Var(y-error)/Var(x-error) for deming().

    lambda = 1 is orthogonal / total least squares; lambda -> inf approaches
    OLS of y-on-x; lambda -> 0 approaches inverse OLS (x-on-y).
    """
    return (sigma_y / sigma_x) ** 2


def deming(x, y, lam=1.0):
    """Closed-form Deming (errors-in-variables) regression. Returns (slope, intercept).

    lam is the ratio Var(y-error)/Var(x-error); lam=1 is orthogonal regression.
    Non-finite pairs are dropped; returns (nan, nan) if fewer than 3 valid points
    or the covariance is zero. Consolidated from research/addis_fabs_ec_deming.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if x.size < 3:
        return np.nan, np.nan
    xbar, ybar = x.mean(), y.mean()
    sxx = np.sum((x - xbar) ** 2)
    syy = np.sum((y - ybar) ** 2)
    sxy = np.sum((x - xbar) * (y - ybar))
    if sxy == 0:
        return np.nan, np.nan
    slope = (
        syy - lam * sxx + np.sqrt((syy - lam * sxx) ** 2 + 4 * lam * sxy ** 2)
    ) / (2 * sxy)
    intercept = ybar - slope * xbar
    return slope, intercept


def deming_bootstrap(x, y, lam, *, groups=None, n_boot=2000,
                     confidence=0.95, seed=20260910):
    """Deming estimates, bootstrap standard errors and percentile intervals.

    Resample paired physical filters, or whole ``groups`` (e.g. calendar months)
    to preserve dependence inside a block. Intervals condition on the supplied
    predictions, calibration choice and fixed lambda: they do not include model
    selection, MAC or error-ratio uncertainty. Returns successful-draw counts.
    """
    if not np.isfinite(lam) or lam <= 0:
        raise ValueError("lam must be finite and positive")
    if not 0 < confidence < 1 or n_boot < 100:
        raise ValueError("confidence must be in (0,1) and n_boot >= 100")
    x, y = np.asarray(x, float), np.asarray(y, float)
    if x.ndim != 1 or x.shape != y.shape:
        raise ValueError("x and y must be paired one-dimensional arrays")
    valid = np.isfinite(x) & np.isfinite(y)
    if groups is not None:
        groups = np.asarray(groups)
        if groups.shape != x.shape or pd.isna(groups).any():
            raise ValueError("groups must be aligned and nonmissing")
        groups = groups[valid]
    x, y = x[valid], y[valid]
    slope, intercept = deming(x, y, lam)
    if not np.isfinite([slope, intercept]).all():
        raise ValueError("Deming fit needs >=3 nondegenerate finite pairs")
    if groups is None:
        blocks = [np.array([i]) for i in range(len(x))]
    else:
        blocks = [np.flatnonzero(groups == g) for g in pd.unique(groups)]
        if len(blocks) < 3:
            raise ValueError("at least three independent groups are required")
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(n_boot):
        take = np.concatenate([blocks[i] for i in rng.integers(len(blocks), size=len(blocks))])
        pair = deming(x[take], y[take], lam)
        if np.isfinite(pair).all():
            draws.append(pair)
    if len(draws) < 0.9 * n_boot:
        raise ValueError("fewer than 90% of bootstrap fits were nondegenerate")
    draws = np.asarray(draws)
    tail = (1 - confidence) / 2
    low, high = np.quantile(draws, [tail, 1 - tail], axis=0)
    se = draws.std(axis=0, ddof=1)
    return {"deming_slope": float(slope), "deming_intercept": float(intercept),
            "deming_lambda": float(lam), "n": len(x), "n_blocks": len(blocks),
            "n_boot": n_boot, "n_boot_valid": len(draws), "confidence": confidence,
            "slope_se": float(se[0]), "intercept_se": float(se[1]),
            "slope_ci_low": float(low[0]), "slope_ci_high": float(high[0]),
            "intercept_ci_low": float(low[1]), "intercept_ci_high": float(high[1]),
            "bootstrap_unit": "group" if groups is not None else "paired_filter"}


def calculate_regression_stats(x, y=None, y_col=None, positive_only=False,
                               errors_in_variables=False, sigma_x=None,
                               sigma_y=None):
    """
    Calculate linear regression statistics. Two call forms:

        calculate_regression_stats(x_array, y_array)
        calculate_regression_stats(df, 'x_col', 'y_col')   # DataFrame form

    NaN and +/-inf pairs are always dropped. With positive_only=True, only
    strictly-positive x and y are kept (appropriate for fAbs/EC, where
    non-positive values are unphysical); off by default so general callers are
    unaffected.

    Returns None if fewer than 3 valid points. Otherwise a dict with:
      n, slope, intercept, r_squared, correlation,
      r2 / R2 (aliases of r_squared), origin_slope (through-origin slope,
      sum(xy)/sum(x^2)), and the agreement metrics RMSE, MAE, bias,
      median_bias (all y-vs-x, i.e. y treated as predicted, x as observed).

    The RMSE/MAE/bias/R2 keys make this a superset of
    ``pls_transfer.regression_metrics``. Those two returned the same OLS R2
    under different key names (`r_squared` vs `R2`), which is why ~30 phase-3
    and absorption call sites could not use the plotting helpers
    (`add_stats_textbox`, `add_regression_line`) and hand-rolled a stats box
    instead. Verified numerically identical before aliasing.

    This consolidates the divergent inline `regression_stats(df, x_col, y_col)`
    copies from improve_hips_offset/spartan; the extra keys and positive_only
    flag exist so those consumers can adopt it without changing behaviour.

    ERRORS IN VARIABLES
    -------------------
    ``slope`` above is ordinary least squares of y on x, which assumes x is
    known exactly. When both axes are *measurements* -- the case whenever a
    panel draws a 1:1 line -- x carries error too, and OLS is biased toward a
    shallower slope (regression dilution). Pass ``errors_in_variables=True`` to
    additionally get:

      deming_slope, deming_intercept, deming_lambda, slope_attenuation_pct

    where ``slope_attenuation_pct`` is 100*(deming_slope - slope)/slope, i.e.
    how much OLS understates the relationship. On this project's filter data the
    shift is 22-37 % for Fabs/MAC-vs-EC comparisons and ~0 % where the two
    variables already track each other closely.

    ``deming_lambda`` is Var(y-error)/Var(x-error). It defaults to 1.0
    (orthogonal regression, equal error variance). Supply ``sigma_x``/``sigma_y``
    when measurement uncertainties are available. HIPS uncertainty is stored in
    ``HIPS_Uncertainty`` parameter rows, not on the ``HIPS_Fabs`` rows; convert
    it with the same MAC used for the plotted x values. The correction's
    magnitude depends on lambda. Use ``deming_bootstrap`` separately for
    conditional standard errors and confidence intervals.

    Off by default: existing callers' stats boxes must not change.
    """
    if isinstance(x, pd.DataFrame):
        df = x
        xa = np.asarray(df[y], dtype=float)
        ya = np.asarray(df[y_col], dtype=float)
    else:
        xa = np.asarray(x, dtype=float)
        ya = np.asarray(y, dtype=float)

    mask = np.isfinite(xa) & np.isfinite(ya)
    if positive_only:
        mask &= (xa > 0) & (ya > 0)
    xa, ya = xa[mask], ya[mask]

    if len(xa) < 3:
        return None

    slope, intercept = np.polyfit(xa, ya, 1)
    correlation = np.corrcoef(xa, ya)[0, 1]
    r_squared = correlation ** 2
    origin_slope = float(np.sum(xa * ya) / np.sum(xa ** 2))

    residual = ya - xa
    result = {
        'n': len(xa),
        'slope': slope,
        'intercept': intercept,
        'r_squared': r_squared,
        'correlation': correlation,
        'r2': r_squared,
        'R2': r_squared,
        'origin_slope': origin_slope,
        'RMSE': float(np.sqrt(np.mean(residual ** 2))),
        'MAE': float(np.mean(np.abs(residual))),
        'bias': float(np.mean(residual)),
        'median_bias': float(np.median(residual)),
    }

    if errors_in_variables:
        if sigma_x is not None and sigma_y is not None:
            lam = float(deming_lambda(sigma_x, sigma_y))
            if not np.isfinite(lam) or lam <= 0:
                lam = 1.0
        else:
            lam = 1.0
        d_slope, d_intercept = deming(xa, ya, lam)
        result['deming_slope'] = d_slope
        result['deming_intercept'] = d_intercept
        result['deming_lambda'] = lam
        result['slope_attenuation_pct'] = (
            float(100.0 * (d_slope - slope) / slope)
            if np.isfinite(d_slope) and slope != 0
            else float('nan')
        )

    return result


def format_equation(slope, intercept):
    """Format regression equation as string."""
    sign = '+' if intercept >= 0 else '-'
    return f"y = {slope:.3f}x {sign} {abs(intercept):.2f}"


def format_stats_text(stats, show_equation=True, extra_text=None):
    """
    Format statistics for display in text box.

    Parameters:
    -----------
    stats : dict from calculate_regression_stats
    show_equation : bool
    extra_text : str (optional additional text)

    Returns:
    --------
    str formatted text
    """
    if stats is None:
        return "Insufficient data"

    text = f"n = {stats['n']}\nR² = {stats['r_squared']:.3f}"

    if show_equation:
        text += f"\n{format_equation(stats['slope'], stats['intercept'])}"

    if extra_text:
        text += f"\n{extra_text}"

    return text


def get_clean_data(x_data, y_data, outlier_mask=None):
    """
    Extract clean (non-NaN, non-outlier) data.

    Parameters:
    -----------
    x_data, y_data : arrays
    outlier_mask : boolean array (True = outlier)

    Returns:
    --------
    tuple: (x_clean, y_clean, x_outliers, y_outliers)
    """
    x_data = np.asarray(x_data)
    y_data = np.asarray(y_data)

    valid_mask = (~np.isnan(x_data)) & (~np.isnan(y_data))

    if outlier_mask is not None:
        outlier_mask = np.asarray(outlier_mask)
        clean_mask = valid_mask & ~outlier_mask
        outlier_plot_mask = valid_mask & outlier_mask
    else:
        clean_mask = valid_mask
        outlier_plot_mask = np.zeros(len(x_data), dtype=bool)

    return (
        x_data[clean_mask],
        y_data[clean_mask],
        x_data[outlier_plot_mask],
        y_data[outlier_plot_mask]
    )


def calculate_axis_limits(data_arrays, padding=0.1, start_zero=True):
    """
    Calculate axis limits from multiple data arrays.

    Parameters:
    -----------
    data_arrays : list of arrays
    padding : float (fraction to add as padding)
    start_zero : bool (if True, min is 0)

    Returns:
    --------
    tuple: (min_val, max_val)
    """
    all_vals = []
    for arr in data_arrays:
        arr = np.asarray(arr)
        valid = arr[~np.isnan(arr)]
        if len(valid) > 0:
            all_vals.extend(valid)

    if len(all_vals) == 0:
        return (0, 100)

    min_val = 0 if start_zero else min(all_vals) * (1 - padding)
    max_val = max(all_vals) * (1 + padding)

    return (min_val, max_val)


def create_grid_layout(n_plots, max_cols=2):
    """
    Create figure and axes for grid layout.

    Parameters:
    -----------
    n_plots : int (number of subplots needed)
    max_cols : int (maximum columns)

    Returns:
    --------
    tuple: (fig, axes_list)
    """
    n_cols = min(n_plots, max_cols)
    n_rows = ceil(n_plots / n_cols)

    from . import PlotConfig
    figsize = PlotConfig.get('figsize_grid')

    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)

    # Flatten axes array for easy iteration
    if n_plots == 1:
        axes_list = [axes]
    else:
        axes_list = axes.flatten().tolist()

    # Hide unused subplots
    for idx in range(n_plots, len(axes_list)):
        axes_list[idx].set_visible(False)

    return fig, axes_list[:n_plots]


def create_individual_figure():
    """Create a single figure with one axes."""
    from . import PlotConfig
    figsize = PlotConfig.get('figsize')
    fig, ax = plt.subplots(figsize=figsize)
    return fig, ax


def create_combined_figure():
    """Create a single figure for combined/overlay plot."""
    from . import PlotConfig
    figsize = PlotConfig.get('figsize')
    fig, ax = plt.subplots(figsize=figsize)
    return fig, ax


def add_stats_textbox(ax, stats, position='upper_left', box_color='white'):
    """
    Add statistics text box to axes.

    Parameters:
    -----------
    ax : matplotlib axes
    stats : dict from calculate_regression_stats
    position : str ('upper_left', 'upper_right', 'lower_left', 'lower_right')
    box_color : str or color
    """
    from . import PlotConfig

    if not PlotConfig.get('show_stats') or stats is None:
        return

    text = format_stats_text(stats)

    positions = {
        'upper_left': (0.05, 0.95, 'top', 'left'),
        'upper_right': (0.95, 0.95, 'top', 'right'),
        'lower_left': (0.05, 0.05, 'bottom', 'left'),
        'lower_right': (0.95, 0.05, 'bottom', 'right'),
    }

    x, y, va, ha = positions.get(position, positions['upper_left'])

    ax.text(x, y, text, transform=ax.transAxes,
            fontsize=PlotConfig.get('font_size') - 1,
            verticalalignment=va, horizontalalignment=ha,
            bbox=dict(boxstyle='round', facecolor=box_color, alpha=0.9))


def add_regression_line(ax, stats, x_range, color='green', label='Best fit'):
    """Add regression line to axes."""
    if stats is None:
        return

    x_line = np.array(x_range)
    y_line = stats['slope'] * x_line + stats['intercept']
    ax.plot(x_line, y_line, color=color, linestyle='-',
            linewidth=2, alpha=0.8, label=label)


def add_one_to_one_line(ax, max_val, label='1:1 line'):
    """Add 1:1 reference line to axes."""
    from . import PlotConfig

    if not PlotConfig.get('show_1to1'):
        return

    ax.plot([0, max_val], [0, max_val], 'k--',
            alpha=0.5, linewidth=1.5, label=label)


def setup_equal_axes(ax, max_val):
    """Setup equal aspect ratio axes starting from 0."""
    ax.set_xlim(0, max_val)
    ax.set_ylim(0, max_val)
    ax.set_aspect('equal', adjustable='box')


def style_axes(ax, xlabel, ylabel, title=None, show_legend=True):
    """Apply consistent styling to axes."""
    from . import PlotConfig

    ax.set_xlabel(xlabel, fontsize=PlotConfig.get('font_size'))
    ax.set_ylabel(ylabel, fontsize=PlotConfig.get('font_size'))

    if title:
        ax.set_title(title, fontsize=PlotConfig.get('title_size'), fontweight='bold')

    if show_legend and PlotConfig.get('show_legend'):
        ax.legend(loc='lower right', fontsize=PlotConfig.get('font_size') - 2)

    ax.grid(True, alpha=PlotConfig.get('grid_alpha'))


def print_stats_table(results_dict, title="Comparison"):
    """
    Print a formatted table of statistics.

    Parameters:
    -----------
    results_dict : dict
        {site_name: stats_dict} or {site_name: {threshold: stats_dict}}
    title : str
    """
    print("\n" + "=" * 70)
    print(f"{title}")
    print("=" * 70)

    for site_name, site_results in results_dict.items():
        if site_results is None:
            print(f"\n{site_name}: No data")
            continue

        if isinstance(site_results, dict) and 'n' in site_results:
            # Single result
            print(f"\n{site_name}:")
            print(f"  n = {site_results['n']}")
            print(f"  R² = {site_results['r_squared']:.3f}")
            print(f"  Slope = {site_results['slope']:.3f}")
        else:
            # Multiple thresholds/periods
            print(f"\n{site_name}:")
            print(f"{'Key':<15s} {'n':>8s} {'R²':>10s} {'Slope':>10s}")
            print("-" * 45)
            for key, stats in site_results.items():
                if stats:
                    print(f"{str(key):<15s} {stats['n']:>8d} "
                          f"{stats['r_squared']:>10.3f} {stats['slope']:>10.3f}")
                else:
                    print(f"{str(key):<15s} {'--':>8s} {'--':>10s} {'--':>10s}")

# Ported verbatim from the retired plotting_legacy.py on 2026-07-26 so the
# notebooks that call it keep identical console output. print_stats_table()
# above is the newer equivalent with different formatting; prefer it for new
# code.
def print_comparison_table(results_dict, metric_name='R^2'):
    """
    Print a comparison table of statistics across sites/thresholds.

    Parameters:
    -----------
    results_dict : dict of dicts with stats
    metric_name : str for table header
    """
    print("\n" + "=" * 80)
    print(f"COMPARISON TABLE: {metric_name}")
    print("=" * 80)

    # Get all sites and thresholds
    sites = list(results_dict.keys())

    for site_name, site_results in results_dict.items():
        if site_results is None:
            print(f"\n{site_name}: No data")
            continue

        if isinstance(site_results, dict) and 'n' in site_results:
            # Single result
            print(f"\n{site_name}:")
            print(f"  n = {site_results['n']}")
            print(f"  R^2 = {site_results['r_squared']:.3f}")
            print(f"  Slope = {site_results['slope']:.3f}")
        else:
            # Multiple thresholds
            print(f"\n{site_name}:")
            print(f"{'Threshold':<15s} {'n':>8s} {'R^2':>10s} {'Slope':>10s}")
            print("-" * 45)
            for threshold, stats in site_results.items():
                if stats:
                    print(f"{threshold:<15} {stats['n']:>8d} "
                          f"{stats['r_squared']:>10.3f} {stats['slope']:>10.3f}")
                else:
                    print(f"{threshold:<15} {'--':>8s} {'--':>10s} {'--':>10s}")
